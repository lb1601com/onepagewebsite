OnePageWebsite
===============

About
-----

Contao extension to create a one page website structure with regular pages

This extension brings the following features:

* Frontend modules to create the page structure with a reference page or with a custom page selection
* Navigation module to navigatio through the sites with anchors
* Mootools template to initialize mooSmoothScroll